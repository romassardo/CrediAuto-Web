import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

interface SendCredentialsEmailParams {
  to: string;
  dealerName: string;
  email: string;
  tempPassword: string;
  loginUrl: string;
}

export async function sendDealerCredentials({
  to,
  dealerName,
  email,
  tempPassword,
  loginUrl
}: SendCredentialsEmailParams) {
  try {
    const { data, error } = await resend.emails.send({
      from: 'CrediAuto <noreply@crediauto.cl>',
      to: [to],
      subject: '¡Bienvenido a CrediAuto! - Credenciales de acceso',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Bienvenido a CrediAuto</title>
        </head>
        <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #f8fafc;">
          <div style="max-width: 600px; margin: 0 auto; background-color: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);">
            
            <!-- Header con gradiente de marca -->
            <div style="background: linear-gradient(135deg, #2e3192 0%, #1e40af 100%); padding: 40px 30px; text-align: center;">
              <h1 style="color: white; margin: 0; font-size: 28px; font-weight: bold;">¡Bienvenido a CrediAuto!</h1>
              <p style="color: rgba(255, 255, 255, 0.9); margin: 10px 0 0 0; font-size: 16px;">Tu concesionario ha sido aprobado</p>
            </div>

            <!-- Contenido principal -->
            <div style="padding: 40px 30px;">
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 0 0 20px 0;">
                Estimado/a <strong>${dealerName}</strong>,
              </p>
              
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 0 0 20px 0;">
                Nos complace informarte que tu solicitud para unirte a CrediAuto ha sido <strong style="color: #059669;">aprobada</strong>. 
                Ya puedes acceder a tu portal de concesionario y comenzar a gestionar tus solicitudes de crédito.
              </p>

              <!-- Credenciales en tarjeta destacada -->
              <div style="background-color: #f8fafc; border: 2px solid #e5e7eb; border-radius: 8px; padding: 24px; margin: 30px 0;">
                <h3 style="color: #1f2937; margin: 0 0 16px 0; font-size: 18px; font-weight: 600;">
                  🔐 Tus credenciales de acceso:
                </h3>
                
                <div style="margin-bottom: 12px;">
                  <strong style="color: #374151; display: inline-block; width: 100px;">Usuario:</strong>
                  <code style="background-color: #e5e7eb; padding: 4px 8px; border-radius: 4px; font-family: 'Courier New', monospace;">${email}</code>
                </div>
                
                <div style="margin-bottom: 16px;">
                  <strong style="color: #374151; display: inline-block; width: 100px;">Contraseña:</strong>
                  <code style="background-color: #fef3c7; padding: 4px 8px; border-radius: 4px; font-family: 'Courier New', monospace; color: #92400e;">${tempPassword}</code>
                </div>

                <div style="background-color: #fef2f2; border-left: 4px solid #ef4444; padding: 12px; border-radius: 4px;">
                  <p style="color: #dc2626; margin: 0; font-size: 14px; font-weight: 500;">
                    ⚠️ Por seguridad, deberás cambiar esta contraseña en tu primer inicio de sesión.
                  </p>
                </div>
              </div>

              <!-- Botón de acceso -->
              <div style="text-align: center; margin: 30px 0;">
                <a href="${loginUrl}" 
                   style="display: inline-block; background: linear-gradient(135deg, #2e3192 0%, #1e40af 100%); 
                          color: white; text-decoration: none; padding: 14px 32px; border-radius: 8px; 
                          font-weight: 600; font-size: 16px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);">
                  Acceder a mi Portal
                </a>
              </div>

              <!-- Información adicional -->
              <div style="background-color: #f0f9ff; border-left: 4px solid #0ea5e9; padding: 16px; border-radius: 4px; margin: 20px 0;">
                <h4 style="color: #0c4a6e; margin: 0 0 8px 0; font-size: 16px;">¿Qué puedes hacer en tu portal?</h4>
                <ul style="color: #0c4a6e; margin: 0; padding-left: 20px; font-size: 14px;">
                  <li>Crear y gestionar ejecutivos de cuentas</li>
                  <li>Calcular préstamos para tus clientes</li>
                  <li>Enviar solicitudes de crédito</li>
                  <li>Hacer seguimiento de tus solicitudes</li>
                </ul>
              </div>

              <p style="color: #6b7280; font-size: 14px; line-height: 1.5; margin: 30px 0 0 0;">
                Si tienes alguna pregunta o necesitas ayuda, no dudes en contactarnos. 
                ¡Bienvenido al equipo CrediAuto!
              </p>
            </div>

            <!-- Footer -->
            <div style="background-color: #f8fafc; padding: 20px 30px; text-align: center; border-top: 1px solid #e5e7eb;">
              <p style="color: #6b7280; font-size: 12px; margin: 0;">
                © 2024 CrediAuto. Todos los derechos reservados.
              </p>
            </div>
          </div>
        </body>
        </html>
      `,
      text: `
¡Bienvenido a CrediAuto!

Estimado/a ${dealerName},

Nos complace informarte que tu solicitud para unirte a CrediAuto ha sido aprobada.

Tus credenciales de acceso:
Usuario: ${email}
Contraseña: ${tempPassword}

IMPORTANTE: Por seguridad, deberás cambiar esta contraseña en tu primer inicio de sesión.

Accede a tu portal en: ${loginUrl}

¡Bienvenido al equipo CrediAuto!
      `
    });

    if (error) {
      console.error('Error sending email:', error);
      return { success: false, error };
    }

    return { success: true, data };
  } catch (error) {
    console.error('Error in sendDealerCredentials:', error);
    return { success: false, error };
  }
}